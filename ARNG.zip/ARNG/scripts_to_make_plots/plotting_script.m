% addpath('carbon_output_13_09/')
% load('12.08_no_di_tri_RN.mat')
c_ba_0= 3.7106;
crosslinks = [14, 15, 16, 26, 27, 28, 39];
% [ p_y ] = lumping_procedure( y2 );
% p_y = p_y/c_ba_0;
% p_y(:, crosslinks) = p_y(:, crosslinks)/2;


%% figure(1)
% plot all concentrations for different temperatures
 T = [293, 303, 313, 323, 333, 343];

for t = 1 : length(T)
    
filename = sprintf('12_09_kinetic_model_diff_0_T_%d.mat', T(t));
load(filename)
plot_functional_groups( t2, y2, O2_upt, PV, hex_sum, pent_sum )

end
%% figure (2)
clear T
T = 293;
filename = sprintf('13_09_kinetic_model_diff_0_T_%d_no_drier.mat', T(1));
load(filename)
plot_peroxides(t2, y2);


%% figure(3)
% plot diffusion results
%clear T
% T = 293;
filename = sprintf('12_09_kinetic_model_diff_0_T_%d.mat', T(1));
load(filename)
plot_functional_groups( t2, y2, O2_upt, PV, hex_sum, pent_sum )

filename = sprintf('12_09_kinetic_model_diff_1_T_%d.mat', T(1));
load(filename)
plot_functional_groups( t2, y2, O2_upt, PV, hex_sum, pent_sum )


%% figure(4)
% plot connectivity information
T = 293;
filename = sprintf('12_09_kinetic_model_diff_0_T_%d.mat', T(1));
load(filename)

plot_connectivity( y2, t2, nr_small );

%% figure(5)
% plot concentration profiles for grammar paper
T = 293;
filename = sprintf('22.08_kinetic_model_diff_0_T_%d.mat', T(1));
load(filename)

plot_conc_for_grammar( y2, t2, O2_upt, nr_small );

%% figure(6)
% plot all concentrations for drier/no drier
  
filename = sprintf('12_09_kinetic_model_diff_0_T_%d.mat', T(1));
load(filename)
plot_functional_groups( t2, y2, O2_upt, PV, hex_sum, pent_sum )

    
filename = sprintf('12_09_kinetic_model_diff_0_T_%d_no_drier.mat', T(1));
load(filename)
plot_functional_groups( t2, y2, O2_upt, PV, hex_sum, pent_sum )
%%
T = 293;
filename = sprintf('13_09_kinetic_model_diff_0_T_%d_no_drier.mat', T(1));
load(filename)
plot_functional_groups( t2, y2, O2_upt, PV, hex_sum, pent_sum )

