function  plot_diffusion_results( t2, y2 )

figure(3)
hFig = figure(3);
set(gcf,'PaperPositionMode','auto')
set(gcf,'color','w');
set(gca,'FontSize',16); 
set(hFig, 'Position', [0 0 1600 300])

hold on
f1 = subplot(1, 4, 1); % EL
set(gca, 'XScale', 'log', 'FontSize', 16);
hold on
f2 = subplot(1, 4, 2); % aldehydes
set(gca, 'XScale', 'log', 'FontSize', 16);
hold on
f3 = subplot(1, 4, 3); % carboxyic acid
set(gca, 'XScale', 'log', 'FontSize', 16);
hold on
f4 = subplot(1, 4, 4); %  radicals
set(gca, 'XScale', 'log', 'FontSize', 16);
hold on


crosslinks = [14, 15, 16, 26, 27, 28, 39];
radicals = [8, 9, 11, 19, 20, 21, 29, 39];
c_ba_0= 3.7106;

p_y = lumping_procedure(y2);
p_y = p_y/c_ba_0;
%1 EL
semilogx(f1, t2(:), p_y(:, 7), 'LineWidth',2);
xlim(f1, [min(t2) max(t2)])
title(f1, 'EL')
xlabel(f1, 'Time (hours)')
ylabel(f1, 'Concentration (mol/mol EL)')

%2 aldehydes
semilogx(f2, t2(:), p_y(:, 18), 'LineWidth',2);
title(f2, 'Aldehydes')
xlim(f2, [min(t2) max(t2)])
xlabel(f2, 'Time (hours)')
ylabel(f2, 'Concentration (mol/mol EL)')

%3 carboxylic acid
semilogx(f3, t2(:), p_y(:, 23), 'LineWidth',2);
title(f3, 'Carboxylic acid')
xlim(f3, [min(t2) max(t2)])
xlabel(f3, 'Time (hours)')
ylabel(f3, 'Concentration (mol/mol EL)')


%4 radicals
semilogx(f4, t2(:), sum(p_y(:, radicals),2), 'LineWidth',2);
title(f4, 'Radicals')
xlim(f4, [min(t2) max(t2)])
xlabel(f4, 'Time (hours)')
ylabel(f4, 'Concentration (mol/mol EL)')



end

