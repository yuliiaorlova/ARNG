function plot_conc_for_grammar( y2, t2, O2_upt, nr )
% plot connectivity information
global Species
figure(5)
hFig = figure(5);
set(gcf,'PaperPositionMode','auto')
set(gcf,'color','w');
set(gca,'FontSize',16); 
set(hFig, 'Position', [0 0 1000 300])

hold on
f1 = subplot(2, 2, 1); % EL
set(gca, 'XScale', 'log', 'FontSize', 16);
hold on
f2 = subplot(2, 2, 2); % O2 uptake
set(gca, 'XScale', 'log', 'FontSize', 16);
hold on
f3 = subplot(2, 2, 3); % types of crosslinks
set(gca, 'XScale', 'log', 'FontSize', 16);
hold on
f4 = subplot(2, 2, 4); % number of crosslinks per monomer
set(gca, 'XScale', 'log', 'FontSize', 16);
hold on


crosslinks = [14, 15, 16, 26, 27, 28, 39];
c_ba_0= 3.7106;

p_y = lumping_procedure(y2);
p_y = p_y/c_ba_0;
p_y(:, crosslinks) = p_y(:, crosslinks)/2;

alkyl_cl = [16, 26];
ether_cl = [15, 28];
peroxy_cl = [14, 27, 39];


OO_cl = [];
O_cl = [];
C_cl = [];

cl_0 = [];
cl_1 = [];
cl_2 = [];
cl_3 = [];


for i =1 : length(Species)
   
    edges = intersect(crosslinks, Species(i).ptrn);
    counts = histc(Species(i).ptrn, edges);
    
    if sum(counts) == 1
        cl_1 = [cl_1; i];
    else if sum(counts) == 2
            cl_2 = [cl_2; i];
        else if sum(counts) == 3
                cl_3 = [cl_3; i];
            else if sum(counts) == 0
                    cl_0 = [cl_0; i];
                end
            end
        end
    end
end

sum_cl_0 = (sum(y2(:, cl_0),2) - sum(y2(:, nr),2))/c_ba_0 ;
sum_cl_1 = 0.5*sum(y2(:, cl_1),2)/c_ba_0;
sum_cl_2 = 0.5*sum(y2(:, cl_2),2)/c_ba_0;
sum_cl_3 = 0.5*sum(y2(:, cl_3),2)/c_ba_0;

semilogx(f1, t2(:), p_y(:, 7), 'LineWidth',2 );
xlim(f1, [min(t2) max(t2)])
xlabel(f1, 'Time (hours)')
ylabel(f1, 'Concentration (mol/mol EL)')
title(f1,'EL');

semilogx(f2, t2(:),  O2_upt(:), 'LineWidth',2 );
xlim(f2, [min(t2) max(t2)])
xlabel(f2, 'Time (hours)')
ylabel(f2, 'Concentration (mol/mol EL)')
title(f2,'Oxygen uptake');


semilogx(f3, t2(:), sum_cl_0(:),  t2(:), sum_cl_1(:), t2(:), sum_cl_2(:), t2(:), sum_cl_3(:), 'LineWidth',2);
xlim(f3, [min(t2) max(t2)])
xlabel(f3, 'Time (hours)')
ylabel(f3, 'Concentration (mol/mol EL)')
title(f3,'number of crosslinks per monomer');
legend(f3,'0', '1', '2', '3');

semilogx(f4, t2(:), sum(p_y(:, alkyl_cl),2), t2(:), sum(p_y(:, ether_cl),2), t2(:), sum(p_y(:, peroxy_cl),2),'LineWidth',2);
xlim(f4, [min(t2) max(t2)])
xlabel(f4, 'Time (hours)')
ylabel(f4, 'Concentration (mol/mol EL)')
title(f4,'Types of crosslinks');
legend(f4, 'Alkyl', 'Ether', 'Peroxy');


end

