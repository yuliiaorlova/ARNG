function plot_peroxides( t2, y2 )
%PLOT_PEROXIDES - plots all components that contribute to the total
%peroxide value: all peroxides, peroxy crosslinks, hydroperoxides, cobalt
%peroxides

figure(2)
hFig = figure(2);
set(gcf,'PaperPositionMode','auto')
set(gcf,'color','w');
set(gca,'FontSize',16); 
set(hFig, 'Position', [0 0 600 400])
hold on

OOH = [10, 22];
peroxides = [2, 3, 9, 10, 14, 21, 22, 25, 27, 32, 39];
pv_cl = [14, 27, 39];
crosslinks = [14, 15, 16, 26, 27, 28, 39];
radicals = [8, 9, 11, 19, 20, 21, 29, 39];
c_ba_0= 3.7106;


p_y = lumping_procedure(y2);
p_y(:, pv_cl) = p_y(:, pv_cl)/2;

%1 PV
semilogx( t2(:), sum(p_y(:, peroxides), 2)/c_ba_0, t2(:), sum(p_y(:, pv_cl), 2)/c_ba_0, t2(:),  sum(p_y(:, OOH), 2)/c_ba_0, 'LineWidth',2);
set(gca, 'XScale', 'log', 'FontSize', 16);
title('Peroxide value')
xlim([min(t2) max(t2)])
xlabel( 'Time (hours)')
ylabel( 'Concentration (mol/mol EL)')
legend('All peroxides', 'Peroxy crosslinks', 'Hydroperoxides')
hold on

% %2 peroxy crosslinks
% semilogx(f2, t2(:), sum(p_y(:, pv_cl), 2)/c_ba_0);
% title(f2, 'Peroxy crosslinks')
% hold on
% 
% %3 OOH
% semilogx(f3, t2(:), sum(p_y(:, OOH), 2)/c_ba_0);
% title(f3, 'OOH')
% hold on
% 
% %4 all non crosslinks peroxides
% semilogx(f4, t2(:), sum(p_y(:, peroxides), 2)/c_ba_0 - sum(p_y(:, pv_cl), 2)/c_ba_0);
% title(f4, ' all non-crosslink peroxides')
% hold on

end

