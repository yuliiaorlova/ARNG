function plot_lipid_oxidation( p_y, y2, t2, Species)
%PLOT_LIPID_OXIDATION plots ba, hydroperoxides, volatile and non-volatile
%end products

% plot to mimic van gorkum
% find volatiles
% global Species
volatiles = zeros(length(t2),1);
hydroperoxides = zeros(length(t2),1);
non_volatiles = zeros(length(t2),1);
crosslinks = [16, 17, 18, 20, 21, 30, 31, 32, 33, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46];
radicals = [10, 11, 13, 19, 24, 25, 26, 30, 34, 39, 42, 45, 47, 48];

for i = 1 : length(Species)
    
    if c_chain_length(Species(i).lbl)<=8 && c_chain_length(Species(i).lbl)>3 && isempty(intersect(crosslinks, Species(i).ptrn)) %&& isempty(intersect(radicals, Species(i).ptrn))
        volatiles = volatiles + y2(:,i);
    else if c_chain_length(Species(i).lbl)>8 
        non_volatiles = non_volatiles + y2(:,i);
        end
    end
    
    if ~isempty(intersect(12, Species(i).ptrn))

        hydroperoxides = hydroperoxides + y2(:,i);
    end
end
non_volatiles = non_volatiles - y2(:,7);

figure(5)
semilogx( t2(:), p_y(:,9), 'LineWidth',2)
hold on
semilogx( t2(:), volatiles(:), 'LineWidth',2)
hold on
semilogx( t2(:), non_volatiles(:), 'LineWidth',2)
hold on
semilogx( t2(:), hydroperoxides(:), 'LineWidth',2)
xlim( [0 max(t2)])
ylim([0 max(non_volatiles)+0.5])
%title( 'van Gorkum plot')
legend('Polyunsaturated lipid', 'Volatiles', 'Non-volatile end products', 'Lipid hydroperoxide')


end

