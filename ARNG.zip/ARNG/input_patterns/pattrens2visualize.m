
for i = 1 : 26

    graph2mol(pattern_non_reactive(i).adj, pattern_non_reactive(i).lbl, i)

end