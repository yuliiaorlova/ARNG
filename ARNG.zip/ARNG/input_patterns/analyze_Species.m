%load('LA_56_Species.mat');

radicals = [6, 7, 9, 19];
crosslinks = [14, 15, 16, 17, 18, 19];
db = [10];
peroxides = [7, 8];
peroxides_cl = [15];
OH_groups = [13];

cl_1 = [];
cl_2 = [];
cl_3 = [];

cl_tot = [];
cl_dir = [];
cl_neutral = [];

cl_alkyl = [];
cl_peroxy = [];
cl_ether = [];

OO = [];
OO_cl = [];

sp_rad = [];
sp_rad_6 = [];
sp_rad_7 = [];
sp_rad_9 = [];
sp_rad_19 = [];

sp_OH = [];
c_db = [];


for i = 1 : length(Species)
    
    if ~isempty(intersect(crosslinks, Species(i).type))
        cl_tot = [cl_tot; i];
    end
    if length(intersect(crosslinks, Species(i).type))==1
        cl_1 = [cl_1; i];
    end
    if length(intersect(crosslinks, Species(i).type))==2
        cl_2 = [cl_2; i];
    end
    if length(intersect(crosslinks, Species(i).type))==3
        cl_3 = [cl_3; i];
    end
    if ~isempty(intersect(peroxides, Species(i).type))
        OO = [OO; i];
    end
    if ~isempty(intersect(peroxides_cl, Species(i).type))
        OO_cl = [OO_cl; i];
    end
    if ~isempty(intersect(radicals, Species(i).type))
        sp_rad = [sp_rad; i];
    end
    if ~isempty(intersect(6, Species(i).type))
        sp_rad_6 = [sp_rad_6; i];
    end
    if ~isempty(intersect(7, Species(i).type))
        sp_rad_7 = [sp_rad_7; i];
    end
    if ~isempty(intersect(9, Species(i).type))
        sp_rad_9 = [sp_rad_9; i];
    end
    if ~isempty(intersect(19, Species(i).type))
        sp_rad_19 = [sp_rad_19; i];
    end
    if ~isempty(intersect(db, Species(i).type))
        c_db = [c_db; i];
    end
    if ~isempty(intersect(14, Species(i).type))
        cl_alkyl = [cl_alkyl; i];
    end
    if ~isempty(intersect(15, Species(i).type))
        cl_peroxy = [cl_peroxy; i];
    end
    if ~isempty(intersect(16, Species(i).type))
        cl_ether = [cl_ether; i];
    end
    if ~isempty(intersect([17, 19], Species(i).type))
        cl_dir = [cl_dir; i];
    end
    if ~isempty(intersect(OH_groups, Species(i).type))
        sp_OH = [sp_OH; i];
    end
    
    
end


%%

 % crosslinks
cl_tot_sum = sum(y1(:, cl_tot),2);
cl_1_sum = sum(y1(:, cl_1),2);
cl_2_sum = sum(y1(:, cl_2),2);
cl_3_sum = sum(y1(:, cl_3),2);

cl_alkyl_sum = sum(y1(:, cl_alkyl), 2);
cl_peroxy_sum = sum(y1(:, cl_peroxy), 2);
cl_ether_sum = sum(y1(:, cl_ether), 2);
cl_dir_sum = sum(y1(:, cl_dir), 2);

% radicals
sp_rad_sum = sum(y1(:, sp_rad),2);
sp_rad_c6 = sum(y1(:, sp_rad_6), 2);
sp_rad_c_dp = sum(y1(:, sp_rad_19), 2);
sp_rad_OO = sum(y1(:, sp_rad_7), 2);
sp_rad_O = sum(y1(:, sp_rad_9), 2);


% peroxides
OO_sum = sum(y1(:, OO),2);
OO_cl_sum = 0.5*sum(y1(:, OO_cl),2);
OO_sum = OO_sum + OO_cl_sum;

% conjugated double bonds
c_db_sum = sum(y1(:, c_db),2);

OH_sum = sum(y1(:, sp_OH), 2);

%check for mass conservation
total_mass = sum(y1(:, :),2);

%%
t2 = t/3600;
rr = find(t2>.1);
%%
figure(12)


hold on
f11=subplot(2,2,1, 'XScale', 'log');
hold on
f21=subplot(2,2,2, 'XScale', 'log');
hold on
f31=subplot(2,2,3, 'XScale', 'log');
hold on
f41=subplot(2,2,4, 'XScale', 'log');
hold on

% plots for the first products

semilogx(f11, t2(rr), y1(rr,5)); 
title(f11,'c ba');

% semilogx(f11, t2(rr), total_mass(rr)); 
% title(f11,'c ba');

semilogx(f41, t2(rr), cl_tot_sum(rr)); 
title(f41, 'cl tot');

semilogx(f31, t2(rr), cl_1_sum(rr)); 
title(f31, 'cl 1');

semilogx(f31, t2(rr), cl_2_sum(rr)); 
title(f31, 'cl 2');

semilogx(f31, t2(rr), cl_3_sum(rr)); 
title(f31, 'cl 3');

semilogx(f21, t2(rr), OO_sum(rr)); 
title(f21, 'peroxide');

%%
figure(13)
hold on
f311=subplot(2,1,1, 'XScale', 'log');
hold on
f411 = subplot(2, 1, 2, 'XScale', 'log');
hold on

semilogx(f311, t2(rr), cl_1_sum(rr)); 
semilogx(f311, t2(rr), cl_2_sum(rr)); 
semilogx(f311, t2(rr), cl_3_sum(rr)); 
title(f311, 'crosslinks');
legend(f311,{'1 crosslink', '2 crosslinks', '3 crosslinks'}, 'FontSize',12);

semilogx(f411, t2(rr), cl_alkyl_sum(rr)); 
semilogx(f411, t2(rr), cl_peroxy_sum(rr)); 
semilogx(f411, t2(rr), cl_ether_sum(rr)); 
title(f411, 'crosslinks');
legend(f411,{'alkyl crosslonks', 'peroxy crosslinks', 'ether crosslinks'}, 'FontSize',12);


%%
figure(14)
hold on
f3111=subplot(2,1,1, 'XScale', 'log');
hold on
f4111=subplot(2,1,2, 'XScale', 'log');

semilogx(f3111, t2(rr), y1(rr,5)); 
%semilogx(f3111, t2(rr), total_mass(rr)); 
legend(f3111,{'bis-allylic C', 'total mass'}, 'FontSize',12);

semilogx(f4111, t2(rr), OO_sum(rr)); 
title(f4111, 'peroxides');
%%
figure(15)
hold on
f111=subplot(1,1,1, 'XScale', 'log');
hold on

semilogx(f111, t2(rr), sp_rad_sum(rr), 'r'); 
semilogx(f111, t2(rr), sp_rad_c6(rr), 'g'); 
semilogx(f111, t2(rr), sp_rad_c_dp(rr), 'b'); 
semilogx(f111, t2(rr), sp_rad_OO(rr), 'm'); 
semilogx(f111, t2(rr), sp_rad_O(rr), 'y'); 
legend({'total radicals','bis-allylic C', 'C radicals after disp.', 'peroxy radicals', 'alkoxy radicals'}, 'FontSize',12)
title(f111, 'radicals');

%%
figure(11)
hold on
f1=subplot(1,1,1, 'XScale', 'log');
hold on

semilogx(f1, t2(rr), c_db_sum(rr), 'r'); 
title(f1, 'conjugated double bonds');


%%
% rate_PV = OO_sum./total_mass;
% 
% figure(16)
% hold on
% f611=subplot(1,1,1, 'XScale', 'log');
% hold on
% semilogx(f611, t2(rr), rate_PV(rr)); 
% title(f611, 'OH groups');
% 

%%

